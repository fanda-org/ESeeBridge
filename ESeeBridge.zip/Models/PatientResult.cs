﻿namespace EseeBridge.Models;

public class PatientResult
{
    public string? PatientId { get; set; }
    public DateTime? DiagDate { get; set; }
    public TestResult RightEyeResult { get; set; }
    public TestResult LeftEyeResult { get; set; }
    public string? DeviceName { get; set; }
    public string? DeviceSerialNumber { get; set; }

    public PatientResult()
    {
        RightEyeResult = new TestResult();
        LeftEyeResult = new TestResult();
    }
}

public class TestResult
{
    public string? TestNumber { get; set; }
    public string? Sphere { get; set; }
    public string? Cylinder { get; set; }
    public string? Axis { get; set; }
    public string? SphericalEquivalent { get; set; }
}